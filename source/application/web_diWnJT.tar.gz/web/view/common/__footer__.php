    <script src="/web/static/js/vendor.js"></script>
    <script src="/web/static/js/app.min.js"></script>
    <!-- page js -->
    <script src="/web/static/js/jquery.dataTables.js"></script>
    <script src="/web/static/js/dataTables.bootstrap4.min.js"></script>
    <!-- <script src="static/js/data-table.js"></script> -->
     <!-- page js -->
    <script src="/web/static/js/Chart.min.js"></script>
    <!--<script src="/web/static/js/bank.js"></script>-->
    <script src="/assets/common/js/art-template.js"></script>
    <script src="/assets/common/js/amazeui.min.js"></script>
    <script src="/assets/common/plugins/layer/layer.js"></script>
    <script src="/assets/common/js/base.js"></script>
    <script src="/web/static/js/selectize.min.js"></script>
    <script src="/web/static/js/summernote-bs4.min.js"></script>
    <script src="/web/static/js/form-elements.js"></script>
    <script src="/web/static/js/bootstrap-datepicker.js"></script>
    <!--<script src="/assets/store/js/select.data.js"></script>-->
    
    
<?php
namespace app\web\service;

class Basics extends \app\common\service\Basics
{

}
<?php
namespace app\web\service;

use app\common\service\Goods as GoodsService;

/**
 * 商品服务类
 * Class Goods
 * @package app\web\service
 */
class Goods extends GoodsService
{

}
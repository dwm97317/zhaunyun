<?php
namespace app\web\model\wow;

use app\common\model\wow\Order as OrderModel;

/**
 * 好物圈订单同步记录模型
 * Class Order
 * @package app\web\model\wow
 */
class Order extends OrderModel
{

}
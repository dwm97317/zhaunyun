<?php
namespace app\web\model\wow;

use app\common\model\wow\Setting as SettingModel;

/**
 * 好物圈设置模型
 * Class Setting
 * @package app\web\model\wow
 */
class Setting extends SettingModel
{

}
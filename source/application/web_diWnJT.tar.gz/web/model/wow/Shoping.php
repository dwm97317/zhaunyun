<?php
namespace app\web\model\wow;

use app\common\model\wow\Shoping as ShopingModel;

/**
 * 好物圈商品收藏记录模型
 * Class Shoping
 * @package app\web\model\wow
 */
class Shoping extends ShopingModel
{

}
<?php
namespace app\web\model\store\shop;

use app\common\model\store\shop\ClerkRel as ClerkRelModel;

/**
 * 门店店员关系记录模型
 * Class Clerk
 * @package app\web\model\store\shop
 */
class ClerkRel extends ClerkRelModel
{

}
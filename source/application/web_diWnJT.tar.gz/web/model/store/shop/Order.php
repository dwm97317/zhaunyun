<?php

namespace app\web\model\store\shop;

use app\common\model\store\shop\Order as OrderModel;

/**
 * 商家门店核销订单记录模型
 * Class Order
 * @package app\web\model\store\shop
 */
class Order extends OrderModel
{

}
<?php
namespace app\web\model\user;

use app\common\model\user\Grade as GradeModel;

/**
 * 用户会员等级模型
 * Class Grade
 * @package app\web\model\user
 */
class Grade extends GradeModel
{

}
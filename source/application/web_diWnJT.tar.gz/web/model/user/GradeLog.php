<?php
namespace app\web\model\user;

use app\common\model\user\GradeLog as GradeLogModel;

/**
 * 用户会员等级变更记录模型
 * Class GradeLog
 * @package app\web\model\user
 */
class GradeLog extends GradeLogModel
{

}